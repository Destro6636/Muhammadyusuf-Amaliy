from django.db import models
from django.utils import timezone

class Category(models.Model):
    name = models.CharField(max_length=100)
    lunch_time = models.DateTimeField(default=timezone.now)

    def __str__(self) -> str:
        return self.name
    
class Foods(models.Model):
    name = models.CharField(max_length=50)
    price = models.IntegerField()
    image = models.ImageField()
    about = models.TextField()
    category = models.ForeignKey(Category, on_delete=models.CASCADE, null=True, blank=True)

    def __str__(self):
        return self.name
    
class Frontpage(models.Model):
    name = models.CharField(max_length=50)
    image = models.ImageField(upload_to='image/', null=True, blank=True)
    description = models.TextField()
    
    def __str__(self):
        return self.name

    
class Menu(models.Model):
    name = models.CharField(max_length=50)
    image = models.ImageField(upload_to='image/', null=True, blank=True)
    description = models.TextField()
    category = models.ForeignKey(Category, on_delete=models.CASCADE, null=True, blank=True)

    def __str__(self):
        return self.name
    
class Reservation(models.Model):
    customer_name = models.CharField(max_length=100)
    reservation_time = models.DateTimeField()
    num_guests = models.IntegerField()

    def __str__(self):
        return self.customer_name
    
class Table(models.Model):
    table_id = models.IntegerField(unique=True)
    seats = models.IntegerField()
    is_reserved = models.BooleanField(default=False)
    reservation = models.ForeignKey(Reservation, on_delete=models.SET_NULL, null=True, blank=True)

    def __str__(self):
        return self.table_id
    
class Contact(models.Model):
    name = models.CharField(max_length=50)
    email = models.EmailField()
    message = models.TextField()

    def __str__(self):
        return self.name
    
class MealTime(models.Model):
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name


    
class Meal(models.Model):
    # """Har bir ovqat vaqti uchun tegishli ovqatni belgilash"""
    meal_time = models.ForeignKey(MealTime, on_delete=models.CASCADE)
    food = models.ForeignKey(Foods, on_delete=models.CASCADE)
    day = models.DateField()

    def __str__(self):
        return self.meal_time
    
class Workshop(models.Model):
    date = models.DateField()
    teacher = models.CharField(max_length=100)
    language = models.CharField(max_length=50)
    location = models.CharField(max_length=200)

    def __str__(self):
        return self.date
    
class Shop(models.Model):
    name = models.CharField(max_length=50)
    send = models.CharField(max_length=255)
    table = models.CharField(max_length=255)

    def __str__(self):
        return self.name

class Blog(models.Model):
    name = models.CharField(max_length=50)
    news = models.CharField(max_length=50)

    def __str__(self):
        return self.name
    
class Blog_Post(models.Model):
    name = models.CharField(max_length=50)
    date = models.TimeField()
    image = models.ImageField(upload_to='image/',)
    about = models.TextField()
    pages = models.IntegerField()
    utility_pages = models.BooleanField(default=False)

    def __str__(self):
        return self.name